from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_error import ApiError
from ...models.patch_api_admin_database_agent_hosts_database_agent_host_instances_database_instance_body import (
    PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceBody,
)
from ...models.patch_api_admin_database_agent_hosts_database_agent_host_instances_database_instance_response_200 import (
    PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200,
)
from ...types import Response


def _get_kwargs(
    database_agent_host: UUID,
    database_instance: UUID,
    *,
    body: PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/api/admin/database-agent-hosts/{database_agent_host}/instances/{database_instance}".format(
            database_agent_host=quote(str(database_agent_host), safe=""),
            database_instance=quote(str(database_instance), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApiError | PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200 | None:
    if response.status_code == 200:
        response_200 = PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 400:
        response_400 = ApiError.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ApiError.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ApiError.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ApiError.from_dict(response.json())

        return response_409

    if response.status_code == 417:
        response_417 = ApiError.from_dict(response.json())

        return response_417

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApiError | PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    database_agent_host: UUID,
    database_instance: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceBody,
) -> Response[ApiError | PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200]:
    """
    Args:
        database_agent_host (UUID):
        database_instance (UUID):
        body (PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200]
    """

    kwargs = _get_kwargs(
        database_agent_host=database_agent_host,
        database_instance=database_instance,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    database_agent_host: UUID,
    database_instance: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceBody,
) -> ApiError | PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200 | None:
    """
    Args:
        database_agent_host (UUID):
        database_instance (UUID):
        body (PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200
    """

    return sync_detailed(
        database_agent_host=database_agent_host,
        database_instance=database_instance,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    database_agent_host: UUID,
    database_instance: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceBody,
) -> Response[ApiError | PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200]:
    """
    Args:
        database_agent_host (UUID):
        database_instance (UUID):
        body (PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200]
    """

    kwargs = _get_kwargs(
        database_agent_host=database_agent_host,
        database_instance=database_instance,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    database_agent_host: UUID,
    database_instance: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceBody,
) -> ApiError | PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200 | None:
    """
    Args:
        database_agent_host (UUID):
        database_instance (UUID):
        body (PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | PatchApiAdminDatabaseAgentHostsDatabaseAgentHostInstancesDatabaseInstanceResponse200
    """

    return (
        await asyncio_detailed(
            database_agent_host=database_agent_host,
            database_instance=database_instance,
            client=client,
            body=body,
        )
    ).parsed
