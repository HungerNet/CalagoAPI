from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_api_admin_egg_repositories_egg_repository_eggs_response_200 import (
    GetApiAdminEggRepositoriesEggRepositoryEggsResponse200,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    egg_repository: UUID,
    *,
    page: int,
    per_page: int,
    search: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["page"] = page

    params["per_page"] = per_page

    params["search"] = search

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/admin/egg-repositories/{egg_repository}/eggs".format(
            egg_repository=quote(str(egg_repository), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetApiAdminEggRepositoriesEggRepositoryEggsResponse200 | None:
    if response.status_code == 200:
        response_200 = GetApiAdminEggRepositoriesEggRepositoryEggsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetApiAdminEggRepositoriesEggRepositoryEggsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    egg_repository: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int,
    per_page: int,
    search: str | Unset = UNSET,
) -> Response[GetApiAdminEggRepositoriesEggRepositoryEggsResponse200]:
    """
    Args:
        egg_repository (UUID):
        page (int):
        per_page (int):
        search (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiAdminEggRepositoriesEggRepositoryEggsResponse200]
    """

    kwargs = _get_kwargs(
        egg_repository=egg_repository,
        page=page,
        per_page=per_page,
        search=search,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    egg_repository: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int,
    per_page: int,
    search: str | Unset = UNSET,
) -> GetApiAdminEggRepositoriesEggRepositoryEggsResponse200 | None:
    """
    Args:
        egg_repository (UUID):
        page (int):
        per_page (int):
        search (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiAdminEggRepositoriesEggRepositoryEggsResponse200
    """

    return sync_detailed(
        egg_repository=egg_repository,
        client=client,
        page=page,
        per_page=per_page,
        search=search,
    ).parsed


async def asyncio_detailed(
    egg_repository: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int,
    per_page: int,
    search: str | Unset = UNSET,
) -> Response[GetApiAdminEggRepositoriesEggRepositoryEggsResponse200]:
    """
    Args:
        egg_repository (UUID):
        page (int):
        per_page (int):
        search (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiAdminEggRepositoriesEggRepositoryEggsResponse200]
    """

    kwargs = _get_kwargs(
        egg_repository=egg_repository,
        page=page,
        per_page=per_page,
        search=search,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    egg_repository: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int,
    per_page: int,
    search: str | Unset = UNSET,
) -> GetApiAdminEggRepositoriesEggRepositoryEggsResponse200 | None:
    """
    Args:
        egg_repository (UUID):
        page (int):
        per_page (int):
        search (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiAdminEggRepositoriesEggRepositoryEggsResponse200
    """

    return (
        await asyncio_detailed(
            egg_repository=egg_repository,
            client=client,
            page=page,
            per_page=per_page,
            search=search,
        )
    ).parsed
