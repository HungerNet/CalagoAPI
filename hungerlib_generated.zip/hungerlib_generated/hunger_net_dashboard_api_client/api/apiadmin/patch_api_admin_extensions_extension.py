from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.patch_api_admin_extensions_extension_body import PatchApiAdminExtensionsExtensionBody
from ...models.patch_api_admin_extensions_extension_response_200 import PatchApiAdminExtensionsExtensionResponse200
from ...types import Response


def _get_kwargs(
    extension: str,
    *,
    body: PatchApiAdminExtensionsExtensionBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/api/admin/extensions/{extension}".format(
            extension=quote(str(extension), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PatchApiAdminExtensionsExtensionResponse200 | None:
    if response.status_code == 200:
        response_200 = PatchApiAdminExtensionsExtensionResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PatchApiAdminExtensionsExtensionResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    extension: str,
    *,
    client: AuthenticatedClient | Client,
    body: PatchApiAdminExtensionsExtensionBody,
) -> Response[PatchApiAdminExtensionsExtensionResponse200]:
    """
    Args:
        extension (str):
        body (PatchApiAdminExtensionsExtensionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PatchApiAdminExtensionsExtensionResponse200]
    """

    kwargs = _get_kwargs(
        extension=extension,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    extension: str,
    *,
    client: AuthenticatedClient | Client,
    body: PatchApiAdminExtensionsExtensionBody,
) -> PatchApiAdminExtensionsExtensionResponse200 | None:
    """
    Args:
        extension (str):
        body (PatchApiAdminExtensionsExtensionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PatchApiAdminExtensionsExtensionResponse200
    """

    return sync_detailed(
        extension=extension,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    extension: str,
    *,
    client: AuthenticatedClient | Client,
    body: PatchApiAdminExtensionsExtensionBody,
) -> Response[PatchApiAdminExtensionsExtensionResponse200]:
    """
    Args:
        extension (str):
        body (PatchApiAdminExtensionsExtensionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PatchApiAdminExtensionsExtensionResponse200]
    """

    kwargs = _get_kwargs(
        extension=extension,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    extension: str,
    *,
    client: AuthenticatedClient | Client,
    body: PatchApiAdminExtensionsExtensionBody,
) -> PatchApiAdminExtensionsExtensionResponse200 | None:
    """
    Args:
        extension (str):
        body (PatchApiAdminExtensionsExtensionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PatchApiAdminExtensionsExtensionResponse200
    """

    return (
        await asyncio_detailed(
            extension=extension,
            client=client,
            body=body,
        )
    ).parsed
