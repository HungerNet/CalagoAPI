from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_error import ApiError
from ...models.delete_api_admin_database_agent_templates_database_agent_template_response_200 import (
    DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200,
)
from ...types import Response


def _get_kwargs(
    database_agent_template: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/api/admin/database-agent-templates/{database_agent_template}".format(
            database_agent_template=quote(str(database_agent_template), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApiError | DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200 | None:
    if response.status_code == 200:
        response_200 = DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = ApiError.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApiError | DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    database_agent_template: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ApiError | DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200]:
    """
    Args:
        database_agent_template (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200]
    """

    kwargs = _get_kwargs(
        database_agent_template=database_agent_template,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    database_agent_template: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> ApiError | DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200 | None:
    """
    Args:
        database_agent_template (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200
    """

    return sync_detailed(
        database_agent_template=database_agent_template,
        client=client,
    ).parsed


async def asyncio_detailed(
    database_agent_template: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ApiError | DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200]:
    """
    Args:
        database_agent_template (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200]
    """

    kwargs = _get_kwargs(
        database_agent_template=database_agent_template,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    database_agent_template: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> ApiError | DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200 | None:
    """
    Args:
        database_agent_template (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | DeleteApiAdminDatabaseAgentTemplatesDatabaseAgentTemplateResponse200
    """

    return (
        await asyncio_detailed(
            database_agent_template=database_agent_template,
            client=client,
        )
    ).parsed
