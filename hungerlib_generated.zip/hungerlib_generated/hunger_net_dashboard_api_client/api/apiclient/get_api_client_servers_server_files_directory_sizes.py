from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_error import ApiError
from ...models.get_api_client_servers_server_files_directory_sizes_response_200 import (
    GetApiClientServersServerFilesDirectorySizesResponse200,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    server: UUID,
    *,
    directory: str,
    depth: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["directory"] = directory

    params["depth"] = depth

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/client/servers/{server}/files/directory-sizes".format(
            server=quote(str(server), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApiError | GetApiClientServersServerFilesDirectorySizesResponse200 | None:
    if response.status_code == 200:
        response_200 = GetApiClientServersServerFilesDirectorySizesResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ApiError.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApiError | GetApiClientServersServerFilesDirectorySizesResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    server: UUID,
    *,
    client: AuthenticatedClient | Client,
    directory: str,
    depth: int | Unset = UNSET,
) -> Response[ApiError | GetApiClientServersServerFilesDirectorySizesResponse200]:
    """
    Args:
        server (UUID):
        directory (str):
        depth (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | GetApiClientServersServerFilesDirectorySizesResponse200]
    """

    kwargs = _get_kwargs(
        server=server,
        directory=directory,
        depth=depth,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    server: UUID,
    *,
    client: AuthenticatedClient | Client,
    directory: str,
    depth: int | Unset = UNSET,
) -> ApiError | GetApiClientServersServerFilesDirectorySizesResponse200 | None:
    """
    Args:
        server (UUID):
        directory (str):
        depth (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | GetApiClientServersServerFilesDirectorySizesResponse200
    """

    return sync_detailed(
        server=server,
        client=client,
        directory=directory,
        depth=depth,
    ).parsed


async def asyncio_detailed(
    server: UUID,
    *,
    client: AuthenticatedClient | Client,
    directory: str,
    depth: int | Unset = UNSET,
) -> Response[ApiError | GetApiClientServersServerFilesDirectorySizesResponse200]:
    """
    Args:
        server (UUID):
        directory (str):
        depth (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | GetApiClientServersServerFilesDirectorySizesResponse200]
    """

    kwargs = _get_kwargs(
        server=server,
        directory=directory,
        depth=depth,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    server: UUID,
    *,
    client: AuthenticatedClient | Client,
    directory: str,
    depth: int | Unset = UNSET,
) -> ApiError | GetApiClientServersServerFilesDirectorySizesResponse200 | None:
    """
    Args:
        server (UUID):
        directory (str):
        depth (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | GetApiClientServersServerFilesDirectorySizesResponse200
    """

    return (
        await asyncio_detailed(
            server=server,
            client=client,
            directory=directory,
            depth=depth,
        )
    ).parsed
