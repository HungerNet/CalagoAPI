from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_error import ApiError
from ...models.delete_api_client_servers_server_backups_groups_backup_group_body import (
    DeleteApiClientServersServerBackupsGroupsBackupGroupBody,
)
from ...models.delete_api_client_servers_server_backups_groups_backup_group_response_200 import (
    DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200,
)
from ...types import Response


def _get_kwargs(
    server: UUID,
    backup_group: UUID,
    *,
    body: DeleteApiClientServersServerBackupsGroupsBackupGroupBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/api/client/servers/{server}/backups/groups/{backup_group}".format(
            server=quote(str(server), safe=""),
            backup_group=quote(str(backup_group), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApiError | DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200 | None:
    if response.status_code == 200:
        response_200 = DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ApiError.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ApiError.from_dict(response.json())

        return response_404

    if response.status_code == 417:
        response_417 = ApiError.from_dict(response.json())

        return response_417

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApiError | DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    server: UUID,
    backup_group: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DeleteApiClientServersServerBackupsGroupsBackupGroupBody,
) -> Response[ApiError | DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200]:
    """
    Args:
        server (UUID):
        backup_group (UUID):
        body (DeleteApiClientServersServerBackupsGroupsBackupGroupBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200]
    """

    kwargs = _get_kwargs(
        server=server,
        backup_group=backup_group,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    server: UUID,
    backup_group: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DeleteApiClientServersServerBackupsGroupsBackupGroupBody,
) -> ApiError | DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200 | None:
    """
    Args:
        server (UUID):
        backup_group (UUID):
        body (DeleteApiClientServersServerBackupsGroupsBackupGroupBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200
    """

    return sync_detailed(
        server=server,
        backup_group=backup_group,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    server: UUID,
    backup_group: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DeleteApiClientServersServerBackupsGroupsBackupGroupBody,
) -> Response[ApiError | DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200]:
    """
    Args:
        server (UUID):
        backup_group (UUID):
        body (DeleteApiClientServersServerBackupsGroupsBackupGroupBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200]
    """

    kwargs = _get_kwargs(
        server=server,
        backup_group=backup_group,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    server: UUID,
    backup_group: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DeleteApiClientServersServerBackupsGroupsBackupGroupBody,
) -> ApiError | DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200 | None:
    """
    Args:
        server (UUID):
        backup_group (UUID):
        body (DeleteApiClientServersServerBackupsGroupsBackupGroupBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | DeleteApiClientServersServerBackupsGroupsBackupGroupResponse200
    """

    return (
        await asyncio_detailed(
            server=server,
            backup_group=backup_group,
            client=client,
            body=body,
        )
    ).parsed
